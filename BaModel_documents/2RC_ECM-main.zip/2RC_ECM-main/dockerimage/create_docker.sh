
# Get the current files
rm -r ecm
cp -r ../ecm ./ecm





# Docker build
sudo docker build -t ecm_model .
